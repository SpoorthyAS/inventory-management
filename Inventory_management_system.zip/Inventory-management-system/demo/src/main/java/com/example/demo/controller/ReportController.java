package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.MaterialIssue;
import com.example.demo.entity.RawMaterial;
import com.example.demo.service.MaterialIssueService;
import com.example.demo.service.RawMaterialService;

@RestController
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private RawMaterialService rawMaterialService;

    @Autowired
    private MaterialIssueService materialIssueService;

    @GetMapping("/rawmaterials")
    public List<RawMaterial> getRawMaterialsReport() {
        return rawMaterialService.getAllRawMaterials();
    }

    @GetMapping("/issues")
    public List<MaterialIssue> getIssuedMaterialsReport() {
        return materialIssueService.getAllIssuedMaterials();
    }

    @GetMapping("/summary")
    public Map<String, Object> getSummaryReport() {
        Map<String, Object> report = new HashMap<>();

        List<RawMaterial> rawMaterials = rawMaterialService.getAllRawMaterials();
        List<MaterialIssue> issues = materialIssueService.getAllIssuedMaterials();

        report.put("totalRawMaterials", rawMaterials.size());
        report.put("totalIssuedRecords", issues.size());
        report.put("rawMaterials", rawMaterials);
        report.put("issuedMaterials", issues);

        return report;
    }
}