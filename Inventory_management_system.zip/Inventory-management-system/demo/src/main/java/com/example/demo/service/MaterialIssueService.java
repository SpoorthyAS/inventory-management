package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.MaterialIssueRequest;
import com.example.demo.entity.MaterialIssue;
import com.example.demo.entity.RawMaterial;
import com.example.demo.repository.MaterialIssueRepository;
import com.example.demo.repository.RawMaterialRepository;

@Service
public class MaterialIssueService {

    @Autowired
    private MaterialIssueRepository materialIssueRepository;

    @Autowired
    private RawMaterialRepository rawMaterialRepository;

    public String issueMaterial(MaterialIssueRequest request) {

        RawMaterial rawMaterial = rawMaterialRepository.findById(request.getRawMaterialId()).orElse(null);

        if (rawMaterial == null) {
            return "Raw material not found";
        }

        if (request.getIssuedQuantity() > rawMaterial.getQuantity()) {
            return "Insufficient stock available";
        }

        // reduce stock
        rawMaterial.setQuantity(rawMaterial.getQuantity() - request.getIssuedQuantity());
        rawMaterialRepository.save(rawMaterial);

        // save issue details
        MaterialIssue issue = new MaterialIssue();
        issue.setRawMaterialId(rawMaterial.getId());
        issue.setMaterialName(rawMaterial.getMaterialName());
        issue.setIssuedQuantity(request.getIssuedQuantity());
        issue.setIssuedToDepartment(request.getIssuedToDepartment());
        issue.setIssueDate(LocalDate.now());

        materialIssueRepository.save(issue);

        return "Material issued successfully and stock updated";
    }

    public List<MaterialIssue> getAllIssuedMaterials() {
        return materialIssueRepository.findAll();
    }
}