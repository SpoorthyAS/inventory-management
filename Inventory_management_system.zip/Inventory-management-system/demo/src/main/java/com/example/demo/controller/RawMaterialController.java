package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.RawMaterial;
import com.example.demo.service.RawMaterialService;

@RestController
@RequestMapping("/rawmaterials")
public class RawMaterialController {

    @Autowired
    private RawMaterialService rawMaterialService;

    @PostMapping("/add")
    public RawMaterial addRawMaterial(@RequestBody RawMaterial rawMaterial) {
        return rawMaterialService.saveRawMaterial(rawMaterial);
    }

    @GetMapping
    public List<RawMaterial> getAllRawMaterials() {
        return rawMaterialService.getAllRawMaterials();
    }

    @GetMapping("/{id}")
    public RawMaterial getRawMaterialById(@PathVariable Long id) {
        return rawMaterialService.getRawMaterialById(id);
    }

    @GetMapping("/stock")
    public List<RawMaterial> viewAllStock() {
        return rawMaterialService.getAllRawMaterials();
    }

    @GetMapping("/stock/{id}")
    public RawMaterial viewStockById(@PathVariable Long id) {
        return rawMaterialService.getRawMaterialById(id);
    }

    @GetMapping("/ved/{category}")
    public List<RawMaterial> getMaterialsByVedCategory(@PathVariable String category) {
        return rawMaterialService.getMaterialsByVedCategory(category);
    }
}