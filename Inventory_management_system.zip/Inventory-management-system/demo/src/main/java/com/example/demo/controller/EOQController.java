package com.example.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.EOQRequest;
import com.example.demo.service.EOQService;

@RestController
@RequestMapping("/eoq")
public class EOQController {

    @Autowired
    private EOQService eoqService;

    @PostMapping("/calculate")
    public Map<String, Object> calculateEOQ(@RequestBody EOQRequest request) {
        return eoqService.calculateEOQ(request);
    }
}