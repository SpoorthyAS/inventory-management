package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "raw_materials")
public class RawMaterial {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String materialName;
    private double orderingCost;
    private double carryingCost;
    private double outOfStockCost;
    private String vedCategory;
    private int quantity;

    public RawMaterial() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public double getOrderingCost() {
        return orderingCost;
    }

    public void setOrderingCost(double orderingCost) {
        this.orderingCost = orderingCost;
    }

    public double getCarryingCost() {
        return carryingCost;
    }

    public void setCarryingCost(double carryingCost) {
        this.carryingCost = carryingCost;
    }

    public double getOutOfStockCost() {
        return outOfStockCost;
    }

    public void setOutOfStockCost(double outOfStockCost) {
        this.outOfStockCost = outOfStockCost;
    }

    public String getVedCategory() {
        return vedCategory;
    }

    public void setVedCategory(String vedCategory) {
        this.vedCategory = vedCategory;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}