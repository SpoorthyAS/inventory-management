package com.example.demo.dto;

public class FOQRequest {

    private Long rawMaterialId;
    private int fixedOrderQuantity;

    public FOQRequest() {
    }

    public Long getRawMaterialId() {
        return rawMaterialId;
    }

    public void setRawMaterialId(Long rawMaterialId) {
        this.rawMaterialId = rawMaterialId;
    }

    public int getFixedOrderQuantity() {
        return fixedOrderQuantity;
    }

    public void setFixedOrderQuantity(int fixedOrderQuantity) {
        this.fixedOrderQuantity = fixedOrderQuantity;
    }
}