package com.example.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.FOQRequest;
import com.example.demo.service.FOQService;

@RestController
@RequestMapping("/foq")
public class FOQController {

    @Autowired
    private FOQService foqService;

    @PostMapping("/calculate")
    public Map<String, Object> calculateFOQ(@RequestBody FOQRequest request) {
        return foqService.calculateFOQ(request);
    }
}