package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.MaterialIssueRequest;
import com.example.demo.entity.MaterialIssue;
import com.example.demo.service.MaterialIssueService;

@RestController
@RequestMapping("/issues")
public class MaterialIssueController {

    @Autowired
    private MaterialIssueService materialIssueService;

    @PostMapping("/issue")
    public String issueMaterial(@RequestBody MaterialIssueRequest request) {
        return materialIssueService.issueMaterial(request);
    }

    @GetMapping
    public List<MaterialIssue> getAllIssuedMaterials() {
        return materialIssueService.getAllIssuedMaterials();
    }
}