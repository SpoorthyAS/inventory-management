package com.example.demo.dto;

public class EOQRequest {

    private Long rawMaterialId;
    private double annualDemand;

    public EOQRequest() {
    }

    public Long getRawMaterialId() {
        return rawMaterialId;
    }

    public void setRawMaterialId(Long rawMaterialId) {
        this.rawMaterialId = rawMaterialId;
    }

    public double getAnnualDemand() {
        return annualDemand;
    }

    public void setAnnualDemand(double annualDemand) {
        this.annualDemand = annualDemand;
    }
}