package com.example.demo.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.FOQRequest;
import com.example.demo.entity.RawMaterial;
import com.example.demo.repository.RawMaterialRepository;

@Service
public class FOQService {

    @Autowired
    private RawMaterialRepository rawMaterialRepository;

    public Map<String, Object> calculateFOQ(FOQRequest request) {

        RawMaterial rawMaterial = rawMaterialRepository.findById(request.getRawMaterialId()).orElse(null);

        if (rawMaterial == null) {
            return null;
        }

        Map<String, Object> response = new HashMap<>();
        response.put("rawMaterialId", rawMaterial.getId());
        response.put("materialName", rawMaterial.getMaterialName());
        response.put("fixedOrderQuantity", request.getFixedOrderQuantity());

        return response;
    }
}