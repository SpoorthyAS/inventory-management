package com.example.demo.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.EOQRequest;
import com.example.demo.entity.RawMaterial;
import com.example.demo.repository.RawMaterialRepository;

@Service
public class EOQService {

    @Autowired
    private RawMaterialRepository rawMaterialRepository;

    public Map<String, Object> calculateEOQ(EOQRequest request) {

        RawMaterial rawMaterial = rawMaterialRepository.findById(request.getRawMaterialId()).orElse(null);

        if (rawMaterial == null) {
            return null;
        }

        double demand = request.getAnnualDemand();
        double orderingCost = rawMaterial.getOrderingCost();
        double carryingCost = rawMaterial.getCarryingCost();

        double eoq = Math.sqrt((2 * demand * orderingCost) / carryingCost);

        Map<String, Object> response = new HashMap<>();
        response.put("rawMaterialId", rawMaterial.getId());
        response.put("materialName", rawMaterial.getMaterialName());
        response.put("annualDemand", demand);
        response.put("orderingCost", orderingCost);
        response.put("carryingCost", carryingCost);
        response.put("eoq", eoq);

        return response;
    }
}