package com.example.demo.dto;

public class MaterialIssueRequest {

    private Long rawMaterialId;
    private int issuedQuantity;
    private String issuedToDepartment;

    public MaterialIssueRequest() {
    }

    public Long getRawMaterialId() {
        return rawMaterialId;
    }

    public void setRawMaterialId(Long rawMaterialId) {
        this.rawMaterialId = rawMaterialId;
    }

    public int getIssuedQuantity() {
        return issuedQuantity;
    }

    public void setIssuedQuantity(int issuedQuantity) {
        this.issuedQuantity = issuedQuantity;
    }

    public String getIssuedToDepartment() {
        return issuedToDepartment;
    }

    public void setIssuedToDepartment(String issuedToDepartment) {
        this.issuedToDepartment = issuedToDepartment;
    }
}